package com.jdbc.run;

import com.jdbc.controller.Controller;

public class Run {
	public static void main(String[] args) {
		new Controller().mainMenu();
	}
}
